import time
from smbus2 import SMBus
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import ssd1306

import sys
import os

# Define I2C parameters
i2c_port = 5
i2c_address = sys.argv[4]  # OLED display I2C address

# Initialize I2C bus
bus = SMBus(i2c_port)

# Create an I2C interface
serial = i2c(port=i2c_port, address=i2c_address)

width = 128
height = 64

# Create an SSD1306 OLED device
try:
  oled = ssd1306(serial, width=width, height=height)
except:
  print("oops!", sys.exc_info()[0], "occurred. OLED not found.")
  os.system("sudo systemctl stop interface_change.service")
  exit()

screen_data = {} # dict: (width, height) →  [font size].
screen_data[(128, 32)] = [14]
screen_data[(128, 64)] = [14]
screen_data[(96, 16)] = [10]
screen_data[(64, 48)] = [7]

from PIL import ImageFont
font = ImageFont.truetype("/home/user/ssd1306_oled/arial/arial.ttf",
  size=screen_data[(width, height)][0])

# Display text on the OLED
with canvas(oled) as draw:
  draw.text((0, 0), sys.argv[1] + ": Link-" + sys.argv[2],
    fill="white", font=font)
  draw.text((0, font.size + 2), "IP: " + sys.argv[3],
    fill="white", font=font)

# Wait for a few seconds before clearing the display
time.sleep(5)

# Clear the OLED display
oled.clear()
oled.cleanup()
