#include <stdio.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>

#include <signal.h>

#define I2C_ADDR "0x3C"
#define DELAY    3
int sockfd;

void cleanup(int status) {
  printf("\ncleaning up.\n");

  close(sockfd);
  exit(0);
}

int main(int argc, char *argv[]) {
  signal(SIGINT, cleanup); // Register a signal handler for SIGINT.
  signal(SIGTERM, cleanup); // Register a signal handler for SIGTERM.

  struct ifreq ifr;
  int prev_link = 0;
  char *ip_addr;

  while(1) {
    /* Open a socket to get the interface information. */
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sockfd == -1) {
      perror("socket");
      exit(1);
    }

    printf("interface name: %s\n", argv[1]);

    memcpy(ifr.ifr_name, argv[1], 10);
    if (ioctl(sockfd, SIOCGIFFLAGS, & ifr) == -1) {
      perror("ioctl");
      exit(1);
    }

    /* Get the link status. */
    int link_status = ifr.ifr_flags & IFF_UP;
    if (link_status) {
      printf("\tLink status: Up\n");

      /* Get the IP address. */
      int retry_count = 0;
      while (ioctl(sockfd, SIOCGIFADDR, & ifr) == -1 && ++retry_count < 1000);
      if (retry_count != 1000) {
        ip_addr = inet_ntoa(((struct sockaddr_in * ) & ifr.ifr_addr)->sin_addr);
      } else {
        ip_addr = "NULL";
      }
    } else {
      printf("\tLink status: Down\n");
      ip_addr = "NULL";
    }
    printf("\tIP address: %s\n", ip_addr);

    if (link_status != prev_link) {
      char command[500] = "sudo python /home/user/ssd1306_oled/display_led.py ";
      strcat(command, argv[1]);
      strcat(command, link_status ? " UP " : " DOWN ");
      strcat(command, ip_addr);
      strcat(command, " ");
      strcat(command, I2C_ADDR);

      int status = system(command);
      if (status) {
        perror("system");
        exit(1);
      }
      prev_link = link_status;
    }

    /* Close the socket. */
    close(sockfd);

    sleep(DELAY);
  }

  return 0;
}
