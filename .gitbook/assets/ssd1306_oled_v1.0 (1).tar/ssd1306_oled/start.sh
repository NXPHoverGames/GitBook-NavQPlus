#!/bin/bash
/home/user/ssd1306_oled/a.out usb0
