# SSD1306 OLED Example Application

This application polls at the desired network interface for its link status and ip address every three seconds, and publishes the same on the SSD1306 OLED module.

## ssd1306_interface_status@.service

It's a daemon service that calls "/home/user/ssd1306_oled/a.out" with the required parameters.

### Parameters:
  * interface
  * display width
  * display height

### Usage example

```bash
sudo mv ssd1306_interface_status@.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start $(systemd-escape --template ssd1306_interface_status@.service "<interface> <display width> <display height>")
sudo systemctl status $(systemd-escape --template ssd1306_interface_status@.service "<interface> <display width> <display height>")
sudo systemctl stop $(systemd-escape --template ssd1306_interface_status@.service "<interface> <display width> <display height>")

# example: sudo systemctl start $(systemd-escape --template ssd1306_interface_status@.service "usb0 128 64")
``````

## interface_status_polling.c

It polls at the desired network interface for its link status and ip address every three seconds, and calls "ssd1306_display_data.py" with the required parameters to publish the network configuration on the OLED display.

### Parameters:
  * interface
  * display width
  * display height

### Usage example

```bash
gcc interface_status_polling.c
sudo ./a.out <interface> <display width> <display height>
# example: ./a.out usb0 128 64
```

## ssd1306_display_data.py

It displays a text string containing the interface name, link status and ip address on the SSD1306 OLED module given by the i2c slave address.
<br>
The font size of the displayed text would depend on the resolution of the OLED. SSD1306 comes in the following resolutions: 128 × 64, 128 × 32, 96 × 16, 64 × 48. The dictionary "screen_data" stores the corresponding font size for all the resolutions. Note: we have only tested with the resolutions 128 × 64 and 128 × 32.

### Parameters:
  * interface
  * ip address
  * link status
  * i2c slave address
  * display width
  * display height

### Usage example

```bash
sudo python ssd1306_display_data.py <interface> <link status> <ip address> <i2c slave address> <display width> <display height>
# example: sudo python ssd1306_display_data.py usb0 UP 255.255.255.255 0x3C 128 64
```
