#include <stdio.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>

#include <signal.h>

#define I2C_ADDR   "0x3C"
#define DELAY      3

int sockfd;

void cleanup(int status) {
  printf("\nCleaning up.\n");

  close(sockfd);
  exit(0);
}

int main(int argc, char *argv[]) {
  signal(SIGINT, cleanup);  // Register a signal handler for SIGINT.
  signal(SIGTERM, cleanup);  // Register a signal handler for SIGTERM.

  struct ifreq ifr;
  char *ip_addr;

  while(1) {
    /* Open a socket to get the interface information. */
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
      perror("socket");
      exit(1);
    }

    memcpy(ifr.ifr_name, argv[1], 10);
    if (ioctl(sockfd, SIOCGIFFLAGS, & ifr) == -1) {
      perror("ioctl");
      exit(1);
    }

    /* Get the link status. */
    int link_status = ifr.ifr_flags & IFF_UP;
    if (link_status) {
      /* Get the IP address. */
      int retry_count = 0;
      /* Retry 1000 times if ip address could not be retrieved. */
      while (ioctl(sockfd, SIOCGIFADDR, & ifr) == -1 && ++retry_count < 1000);

      if (retry_count != 1000) {
        ip_addr = inet_ntoa(((struct sockaddr_in * ) & ifr.ifr_addr)->sin_addr);
      } else {
        ip_addr = "NULL";
      }
    } else {
      ip_addr = "NULL";
    }

    /* Display interface configuration on console output. */
    printf("Interface name: %s,    Link status: %s,    IP address: %s\n", argv[1],
      link_status ? "UP" : "DOWN", ip_addr);

    char command[500] = "sudo python /home/user/ssd1306_oled/ssd1306_display_data.py ";
    strcat(command, argv[1]);  // interface name.
    strcat(command, link_status ? " UP " : " DOWN ");
    strcat(command, ip_addr);  // ipv4 address.
    strcat(command, " ");
    strcat(command, I2C_ADDR);  // i2c slave address.
    strcat(command, " ");
    strcat(command, argv[2]);  // display width.
    strcat(command, " ");
    strcat(command, argv[3]);  // display height.

    /* Display the network configuration on OLED by running ssd1306_display_data.py. */
    int status = system(command);
    if (status) {
      perror("system");
      exit(1);
    }

    /* Close the socket. */
    close(sockfd);

    sleep(DELAY);
  }

  return 0;
}
